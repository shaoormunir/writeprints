from writeprints.feature_extractor import FeatureExtractor
from writeprints.text_processor import Processor
from . import resources